<?php
		if($_GET['isi']=="slider-tabel"){
			include "slider/slider-tabel.php";
		}
		if($_GET['isi']=="slider-input"){
			include "slider/slider-input.php";
		}
		if($_GET['isi']=="slider-edit"){
			include "slider/slider-edit.php";
		}
		if($_GET['isi']=="event-tabel"){
			include "event/event-tabel.php";
		}
		if($_GET['isi']=="event-input"){
			include "event/event-input.php";
		}
		if($_GET['isi']=="event-edit"){
			include "event/event-edit.php";
		}

		if($_GET['isi']=="galeri-tabel"){
			include "galeri/galeri-tabel.php";
		}
		if($_GET['isi']=="galeri-input"){
			include "galeri/galeri-input.php";
		}
		if($_GET['isi']=="galeri-edit"){
			include "galeri/galeri-edit.php";
		}

		if($_GET['isi']=="pengurus-tabel"){
			include "pengurus/pengurus-tabel.php";
		}
		if($_GET['isi']=="pengurus-input"){
			include "pengurus/pengurus-input.php";
		}
		if($_GET['isi']=="pengurus-edit"){
			include "pengurus/pengurus-edit.php";
		}

	

?>